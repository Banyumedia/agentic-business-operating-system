# EXECUTION PLAN & TASK QUEUE
## Panduan Autopilot untuk Autonomous AI Agent

Agent pelaksana HARUS mengikuti urutan ini secara berurutan. Setiap fase selesai → test hijau → commit → push → laporan berkala.

---

## Fase 1: UI Kernel & Dynamic Sidebar (Prioritas D-16 Opsi B)

| ID | Task | File Target | Acceptance Criteria |
|---|---|---|---|
| T-01 | Buat model `BusinessPreset` + seeder 6 preset (`agency`, `fnb`, `pharmacy`, `eo`, `contractor`, `rental`, `custom`) | `app/Models/BusinessPreset.php`, `database/seeders/*.php` | Seeder jalan. 6 preset + custom terdaftar di DB. |
| T-02 | Tambah kolom `business_preset` ke tabel `companies` | migration | Kolom enum default `custom`. Migration berjalan bersih. |
| T-03 | Implementasikan `Company::feature()` + `hasAnyFeature()` + override `module_settings` | `app/Models/Company.php` | Test isolasi tenant. Override tenant A tidak bocor ke tenant B. |
| T-04 | Buat `DynamicMenuRegistry::resolveFor()` | `app/Services/DynamicMenuRegistry.php` | Test unit registry. Menu mati tidak dirender ke HTML. |
| T-05 | Middleware `EnsureFeatureEnabled` | `app/Http/Middleware/EnsureFeatureEnabled.php` | Test 403 saat fitur off, 200 saat on. |
| T-06 | Ganti hardcode sidebar di Blade → render via `DynamicMenuRegistry` | `resources/views/layouts/app.blade.php`, `resources/views/layouts/navigation.blade.php` | Menu apotek tidak muncul untuk tenant agency. Zero bloat terverifikasi. |
| T-07 | Implementasikan tab navigasi horizontal di `/settings` (Tab 1..6) | `resources/views/admin/settings/*.blade.php` | UI tab-based friendly, dynamic theme picker (U-06) aktif. |

## Fase 2: Fondasi Pajak (Add-on & Campuran D-17)

| ID | Task | File Target | Acceptance Criteria |
|---|---|---|---|
| T-08 | Tambah `price_includes_tax` dan `tax_mode` ke `business_identities` | migration | Kolom `price_includes_tax` default false, `tax_mode` enum `taxable`/`non_taxable`/`mixed` default non_taxable. |
| T-09 | Implementasikan `TaxRateService::calculateTax()` (normalisasi rate, inclusive vs exclusive) | `app/Services/TaxRateService.php` | Test TDD RED→GREEN. Inclusive menghasilkan `DPP = total/1.11`, exclusive menghasilkan `PPN = dpp*0.11`, rate 11 vs 0.11 dinormalisasi aman. |
| T-10 | Update `CustomerInvoiceService` & `QuotationService` agar memakai TaxRateService | `app/Services/*.php` | Test regression hijau. Invoice dengan flag `price_includes_tax=true` menghasilkan `grand_total` benar. |

## Fase 3: Fondasi Membership & Tenant Isolation

| ID | Task | File Target | Acceptance Criteria |
|---|---|---|---|
| T-11 | Migration tabel `membership_plans` dan `memberships` | migration | Skema DB canonical, limit grup WA, kuota token bulanan. |
| T-12 | Binding grup WhatsApp berbasis role (`pos`, `warehouse`, `finance`) dan kuota membership | service + handler | Cegah bot invite melebihi `max_wa_groups`. |

## Fase 4: CRM & Data Model Industri (Decoupled Modular D-18)

| ID | Task | File Target | Acceptance Criteria |
|---|---|---|---|
| T-13 | Migration delta `crm_leads` (tambah kolom baru, indeks company_id) | migration | Tanpa truncate tabel eksis. PIC name & status aman. |
| T-14 | Migration delta `pharmacy_prescriptions` & tabel baru `pharmacy_patients` | migration | FK dan index valid. Status enum konsisten. |
| T-15 | Migration delta POS & F&B (`pos_shifts`, `pos_bills`) | migration | Kolom baru terpasang bersih di atas tabel eksis. |
| T-16 | Migration `rental_units`, `rental_bookings`, `rental_incidents` | migration | Skema valid, index company_id aktif. |
| T-17 | Migration `eo_events`, `eo_vendors`, `eo_crew_assignments` | migration | Index `company_id` aktif untuk isolasi query. |

## Fase 5: Integrasi NalarinPesan Webhook

| ID | Task | File Target | Acceptance Criteria |
|---|---|---|---|
| T-18 | Webhook controller terima event `order.created` + validasi idempotency | `app/Http/Controllers/Api/NalarinPesanWebhookController.php` | Test webhook idempotent, payload sama tidak membuat order duplikat. |
| T-19 | Mapping pesanan ke Open Bill / POS (jika tenant F&B) | controller + service | Test order masuk jadi bill meja terkait. |
| T-20 | Catat customer/lead ke CRM otomatis | service | Test customer tersimpan tanpa form manual. |

## Fase 6: UAT, QA, dan Peluncuran Bertahap

| ID | Task | Acceptance Criteria |
|---|---|---|
| T-21 | Full regression suite green (semua unit & feature test hijau) | Seluruh test hijau. |
| T-22 | Audit white-label & tenant isolation (grep vendor string, test cross-tenant) | 0 leak, 0 vendor string di UI. |
| T-23 | Build production + smoke test live per tenant | `npm run build` + HTTP 200 untuk 6 preset tenant dogfood. |

---

## Aturan Eksekusi Autopilot Wajib
1. **Satu writer per worktree.** Jangan commit di worktree milik agent lain.
2. **Selalu `git log --oneline -3`** sebelum commit untuk deteksi race (Copilot autopilot bisa commit lebih dulu).
3. **TDD strict:** Setiap service baru punya test terlebih dahulu (RED) lalu implementasi (GREEN).
4. **Jangan composer install di worktree** yang akan memicu `dump-autoload` di main repo.
5. **Laporan berkala** setiap fase selesai, sertakan bukti live (HTTP status + test count).
