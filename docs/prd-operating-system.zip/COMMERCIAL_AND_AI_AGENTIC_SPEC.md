# COMMERCIAL & AI AGENTIC SPECIFICATION
## Arsitektur Jasa Karyawan AI, Membership SaaS & Integrasi Ekosistem

**Versi:** 1.0.0-PROD  
**Konteks Bisnis:** ERP Prime dirombak menjadi fondasi **Agentic Business Operating System (BOS)** — penjualan jasa **Karyawan AI (Hermes Engine)** yang dibungkus dengan UI ERP modern dan membership bertingkat.

---

## 1. Pemisahan Tegas Dua Produk Ekosistem

```
┌────────────────────────────────────────────────────────┐
│               NALARPESAN (Mini POS & CRM WA)            │
│  Tujuan: Memudahkan pelanggan pesan via WA / Web QR     │
│  Fokus : Order Intake, Menu Catalog, Scan Meja, QRIS    │
└──────────────────────────┬─────────────────────────────┘
                           │ Webhook Bridge (Idempotent)
                           ▼
┌────────────────────────────────────────────────────────┐
│               AGENTIC BOS (ERP Prime + AI Karyawan)    │
│  Tujuan: Back-office, Akuntansi, Kontrol AI Multi-Grup │
│  Fokus : SOP Otomatis, Laporan Keuangan, Approval Bos  │
└────────────────────────────────────────────────────────┘
```

1. **NalarPesan:**
   - Aplikasi Mini POS & CRM interaksi pelanggan depan (*front-facing*).
   - Nilai lebih utama: Pesan langsung via WhatsApp tanpa install aplikasi, kumpul nomor WA otomatis untuk database CRM.
2. **Agentic BOS (ERP Prime):**
   - Sistem operasi internal bisnis (*back-office & intelligence*).
   - Nilai lebih utama: **Karyawan AI (Hermes)** yang membaca data ERP, menjalankan SOP, dan melapor ke Bos di WhatsApp.

---

## 2. Arsitektur Membership & Pricing Dinamis (Non-Hardcode)

Sistem membership **TIDAK DI-HARDCODE** di kode program. Tabel `memberships` dan `membership_plans` menyimpan parameter kuota dan harga yang dapat diubah kapan saja oleh Platform Super Admin.

### 2.1 Skema Data Membership (`membership_plans`)

| Field | Tipe Data | Keterangan |
|---|---|---|
| `id` | BIGINT PK | Auto increment |
| `name` | VARCHAR(64) | Contoh: Starter, Growth, Pro, Enterprise |
| `slug` | VARCHAR(32) UNIQUE | `starter`, `growth`, `pro`, `enterprise` |
| `monthly_price` | DECIMAL(18,2) | Biaya langganan per bulan (dinamis) |
| `annual_price` | DECIMAL(18,2) | Biaya langganan per tahun (diskon) |
| `max_wa_groups` | INT | Batas grup WhatsApp yang boleh di-invite bot |
| `monthly_token_quota`| BIGINT | Kuota base token AI per bulan |
| `allowed_presets` | JSON | Daftar preset bisnis yang boleh dipilih |
| `features` | JSON | Feature flags yang terbuka untuk paket ini |
| `is_active` | BOOLEAN | Status aktif katalog |

### 2.2 Simulasi Paket (Dapat Diedit Manual di Super Admin)

> *Catatan: Angka di bawah adalah simulasi awal untuk riset pasar, bukan hardcode.*

| Parameter | Simulasi: Starter | Simulasi: Pro / Growth | Simulasi: Enterprise |
|---|---|---|---|
| **Target Bisnis** | Usaha Rintisan / 1 Cabang | Bisnis Berkembang / 2-5 Cabang | Korporasi / Jaringan Cabang |
| **Harga Acuan** | Rp 500.000 – Rp 1.000.000 / bln | Rp 2.000.000 – Rp 3.500.000 / bln | Rp 10.000.000+ / bln |
| **Karyawan AI (Hermes)** | 1 Asisten (Grup Kasir/Admin) | 3 Asisten (Kasir, Gudang, Keuangan) | Unlimited Asisten & Grup Khusus |
| **DM Bos (Personal CFO)**| Ringkasan Mingguan | Full Analisis Finansial Realtime + Approval | Kustom Model & Fine-tuning |
| **Kuota Base Token** | 500.000 token / bln | 3.000.000 token / bln | 15.000.000+ token / bln |
| **Topup Add-on Token** | QRIS Mandiri via Dashboard | QRIS Mandiri via Dashboard | Invoicing Korporat |
| **WhatsApp Engine** | Shared / BYON Baileys QR | BYON Baileys / Meta API | Dedicated Meta Cloud API Centang Hijau |
| **Infrastruktur** | Shared Multi-Tenant DB | Shared Multi-Tenant DB | Dedicated VPS / On-Premise |

---

## 3. Rekomendasi Arsitektur Multi-Tenant untuk Target 500 Klien

Untuk mencapai skala 500 klien aktif secara stabil, hemat biaya server, dan mudah di-maintain:

### 3.1 Model Hibrida 2-Tier

```
[ Klien 1 - 480 (SaaS Multi-Tenant) ]
  ├── 1 Cluster Database ERP (MySQL / MariaDB dengan Tenant Isolation via `company_id` scoping)
  ├── 1 Server Gateway AI / Hermes Process Manager
  └── Profil Direktori Terisolasi: `~/.hermes/profiles/{tenant_slug}/`
      ├── SOUL.md (Identitas bisnis & SOP hasil generate form)
      ├── config.yaml (Whitelist tools: hanya MCP ERP, terminal/shell OFF)
      └── state.db (Histori chat terisolasi per tenant)

[ Klien Enterprise 1 - 20 (Dedicated Private Cloud) ]
  └── 1 VPS Khusus per Klien (Docker Compose: NalarPesan + Dedicated DB via TenantProvisioner + Hermes Dedicated)
```

### 3.2 Alur Provisioning Otomatis Saat Onboarding Klien Baru

Ketika klien membeli paket membership:
1. **DB ERP:** Buat record `Company`, `BusinessIdentity` (Tax mode), dan `User` owner.
2. **Membership:** Pasang `CompanyMembership` aktif dengan kuota grup & token sesuai paket.
3. **Preset Bisnis:** Jalankan seeder preset (misal: `pharmacy`) → load default feature flags.
4. **Hermes Profile:**
   - Jalankan `php artisan tenant:provision-ai-profile {slug} --company-id={id}`
   - Sistem membuat folder `~/.hermes/profiles/{slug}/`.
   - Mengisi `SOUL.md` baku (nama bisnis, SOP dasar, instruksi kasir).
   - Mengunci `config.yaml` dengan whitelist tool MCP (`mcp_erp_company_{id}`) dan menonaktifkan tool berisiko tinggi.
5. **WhatsApp QR:** Tampilkan QR pairing di menu `/settings/ai-agent` untuk ditautkan oleh owner.

---

## 4. Keamanan & White-Label Karyawan AI

1. **Anti-Jailbreak Form SOP:**
   - Klien dilarang mengedit file `SOUL.md` atau system prompt secara langsung.
   - Klien hanya mengisi form terstruktur di UI ERP (contoh: Toleransi Diskon Kasir: `10%`, Jam Operasional: `08.00 - 22.00`).
   - Service backend merakit data form menjadi instruksi aman di `SOUL.md`.
2. **Pembersihan Jejak Engine (White-Label 100%):**
   - Menghilangkan nama Hermes, Nous Research, atau framework open-source di respons teks, pesan error, dan metadata API.
   - Respon bot murni memposisikan diri sebagai *"Asisten Digital [Nama Bisnis Tenant]"*.
3. **Guard Kuota & Role Grup WA:**
   - Bot menolak diundang ke grup melebihi kuota `max_wa_groups`.
   - Di grup Kasir, bot tidak bisa membaca laporan laba-rugi atau gaji karyawan.
   - Di DM Bos, bot memiliki wewenang penuh membaca metrik keuangan dan meminta 2-step confirmation untuk aksi approval.
