# DATA MODEL SPECIFICATION
## Skema Database Multi-Business Multi-Tenant (Clean / Canonical)

**Codebase:** Laravel, `/home/tejo/agentic/projects/erp-prime`.

---

## 1. Perubahan Tabel Eksis

### 1.1 `companies`
```sql
ALTER TABLE companies
  ADD COLUMN business_preset ENUM('agency','fnb','pharmacy','eo','contractor','rental','custom')
  NOT NULL DEFAULT 'custom';
```

### 1.2 `business_identities` (Tax Mode)
```sql
ALTER TABLE business_identities
  ADD COLUMN price_includes_tax BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN tax_mode ENUM('taxable','non_taxable') NOT NULL DEFAULT 'non_taxable';
```
> Sebelum migrate, cek dulu apakah `tax_mode`/`tax_preference` sudah ada di tabel `business_identities` atau `financial_books` — jangan duplikat kolom. Kalau sudah ada, cukup tambah `price_includes_tax`.

### 1.3 `module_settings`
- Sudah ada (key-value JSON per company). Dipakai untuk override feature flags.
- Konvensi key: `features.<flag>` (contoh `features.crm.leads`), value `"true"` / `"false"`.
- Scope: `company_id`.

---

## 2. Tabel Baru — Kernel

### 2.1 `business_presets`
```sql
CREATE TABLE business_presets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    key VARCHAR(32) NOT NULL UNIQUE,     -- agency | fnb | pharmacy | eo | contractor | rental
    name VARCHAR(64) NOT NULL,
    description TEXT NULL,
    default_features JSON NOT NULL,      -- array feature-flag default
    is_system BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);
```

---

## 3. Tabel CRM (Delta Migration di atas Tabel Eksis)

### 3.1 `crm_leads` (Tambahan Kolom)
Tabel `crm_leads` sudah ada di codebase. Migration menambahkan kolom berikut jika belum ada:
```sql
ALTER TABLE crm_leads
    ADD COLUMN identity_id BIGINT UNSIGNED NULL,
    ADD COLUMN pic_name VARCHAR(191) NULL,          -- hanya dipakai jika feature crm.pic on
    ADD COLUMN pic_wa VARCHAR(32) NULL,
    ADD COLUMN stage VARCHAR(32) NOT NULL DEFAULT 'new',
    ADD COLUMN deal_value DECIMAL(18,2) NULL,
    ADD COLUMN expected_close_date DATE NULL,
    ADD COLUMN source VARCHAR(32) NULL,             -- wa | referral | event | manual
    ADD COLUMN metadata JSON NULL;
```

### 3.2 `crm_activity_logs`
```sql
CREATE TABLE crm_activity_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lead_id BIGINT UNSIGNED NOT NULL,
    company_id BIGINT UNSIGNED NOT NULL,
    type ENUM('call','wa','meeting','email','note','stage_change') NOT NULL,
    content TEXT NULL,
    user_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NULL,
    INDEX idx_crm_activity_company (company_id),
    CONSTRAINT fk_crm_activity_lead FOREIGN KEY (lead_id) REFERENCES crm_leads(id) ON DELETE CASCADE
);
```

---

## 4. Tabel Baru — Apotek

### 4.1 `pharmacy_patients`
```sql
CREATE TABLE pharmacy_patients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    customer_id BIGINT UNSIGNED NULL,
    name VARCHAR(191) NOT NULL,
    wa_number VARCHAR(32) NULL,
    allergies JSON NULL,
    chronic_conditions JSON NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_pharmacy_patients_company (company_id)
);
```

### 4.2 `pharmacy_prescriptions`
```sql
CREATE TABLE pharmacy_prescriptions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    patient_id BIGINT UNSIGNED NULL,
    doctor_name VARCHAR(191) NULL,
    doctor_sip VARCHAR(64) NULL,
    image_path VARCHAR(255) NULL,        -- foto resep (WA/OCR intake)
    extracted_data JSON NULL,            -- [{drug, qty, dosage, signa}]
    status ENUM('draft','pharmacist_verify','verified','served','cancelled') NOT NULL DEFAULT 'draft',
    verified_by BIGINT UNSIGNED NULL,    -- apoteker
    served_at TIMESTAMP NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_pharmacy_prescriptions_company (company_id)
);
```

---

## 5. Tabel Baru — POS

### 5.1 `pos_shifts`
```sql
CREATE TABLE pos_shifts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    outlet_id BIGINT UNSIGNED NULL,
    cashier_id BIGINT UNSIGNED NOT NULL,
    opening_float DECIMAL(18,2) NOT NULL DEFAULT 0,
    actual_cash DECIMAL(18,2) NOT NULL DEFAULT 0,
    variance DECIMAL(14,2) NOT NULL DEFAULT 0,
    opened_at TIMESTAMP NOT NULL,
    closed_at TIMESTAMP NULL,
    INDEX idx_pos_shifts_company (company_id)
);
```

### 5.2 `pos_bills`
```sql
CREATE TABLE pos_bills (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    shift_id BIGINT UNSIGNED NOT NULL,
    table_id BIGINT UNSIGNED NULL,
    status ENUM('open','paid','cancelled') NOT NULL DEFAULT 'open',
    opened_at TIMESTAMP NOT NULL,
    closed_at TIMESTAMP NULL,
    INDEX idx_pos_bills_company (company_id),
    CONSTRAINT fk_pos_bills_shift FOREIGN KEY (shift_id) REFERENCES pos_shifts(id) ON DELETE CASCADE
);
```

---

## 6. Tabel Baru — Rental (Persewaan)

### 6.1 `rental_units`
```sql
CREATE TABLE rental_units (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(191) NOT NULL,
    category VARCHAR(64) NOT NULL,
    status ENUM('available','rented','maintenance','retired') NOT NULL DEFAULT 'available',
    condition_notes TEXT NULL,
    purchase_cost DECIMAL(18,2) NULL,
    acquired_date DATE NULL,
    metadata JSON NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_rental_units_company (company_id)
);
```

### 6.2 `rental_bookings`
```sql
CREATE TABLE rental_bookings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    unit_id BIGINT UNSIGNED NOT NULL,
    customer_id BIGINT UNSIGNED NOT NULL,
    renter_identity JSON NULL,           -- {ktp, address}
    pickup_datetime DATETIME NOT NULL,
    return_datetime DATETIME NOT NULL,
    actual_return DATETIME NULL,
    daily_rate DECIMAL(18,2) NOT NULL,
    deposit_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
    late_fee_per_hour DECIMAL(18,2) NOT NULL DEFAULT 0,
    late_fee_total DECIMAL(18,2) NOT NULL DEFAULT 0,
    status ENUM('draft','confirmed','out','returned','overdue','cancelled') NOT NULL DEFAULT 'draft',
    metadata JSON NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_rental_bookings_company (company_id),
    CONSTRAINT fk_rental_bookings_unit FOREIGN KEY (unit_id) REFERENCES rental_units(id)
);
```

### 6.3 `rental_incidents`
```sql
CREATE TABLE rental_incidents (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    booking_id BIGINT UNSIGNED NOT NULL,
    type ENUM('damage','loss','late','other') NOT NULL,
    description TEXT NULL,
    charge_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NULL,
    INDEX idx_rental_incidents_company (company_id),
    CONSTRAINT fk_rental_incidents_booking FOREIGN KEY (booking_id) REFERENCES rental_bookings(id)
);
```

---

## 7. Tabel Baru — Event Organizer

### 7.1 `eo_events`
```sql
CREATE TABLE eo_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(191) NOT NULL,
    event_date DATE NOT NULL,
    venue VARCHAR(191) NULL,
    status ENUM('draft','planned','running','done','cancelled') NOT NULL DEFAULT 'draft',
    budget DECIMAL(18,2) NULL,
    metadata JSON NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_eo_events_company (company_id)
);
```

### 7.2 `eo_vendors`
```sql
CREATE TABLE eo_vendors (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    event_id BIGINT UNSIGNED NOT NULL,
    vendor_name VARCHAR(191) NOT NULL,
    service_type VARCHAR(64) NULL,       -- sound | lighting | stage | catering | talent
    fee DECIMAL(18,2) NULL,
    payment_status ENUM('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_eo_vendors_company (company_id),
    CONSTRAINT fk_eo_vendors_event FOREIGN KEY (event_id) REFERENCES eo_events(id) ON DELETE CASCADE
);
```

### 7.3 `eo_crew_assignments`
```sql
CREATE TABLE eo_crew_assignments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    event_id BIGINT UNSIGNED NOT NULL,
    crew_name VARCHAR(191) NOT NULL,
    role VARCHAR(64) NULL,
    assignment_time DATETIME NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_eo_crew_company (company_id),
    CONSTRAINT fk_eo_crew_event FOREIGN KEY (event_id) REFERENCES eo_events(id) ON DELETE CASCADE
);
```

---

## 8. Tabel Baru — Kontraktor (Retensi)

### 8.1 `contractor_retentions`
```sql
CREATE TABLE contractor_retentions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    project_id BIGINT UNSIGNED NOT NULL,
    invoice_id BIGINT UNSIGNED NULL,
    retention_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
    release_date DATE NULL,
    status ENUM('held','released') NOT NULL DEFAULT 'held',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_contractor_retentions_company (company_id)
);
```
> Kontraktor memakai ulang `project_center` + `subcontractor_spk` yang sudah ada di codebase; tabel retensi ini hanya untuk mencatat dana retensi tertahan dan jadwal rilisnya.

---

## 9. Tabel Baru — Komersial SaaS & Membership (Align D-05)

### 9.1 `membership_plans`
```sql
CREATE TABLE membership_plans (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(64) NOT NULL,            -- Starter, Pro, Enterprise
    slug VARCHAR(64) NOT NULL UNIQUE,
    monthly_price DECIMAL(18,2) NOT NULL DEFAULT 0,
    annual_price DECIMAL(18,2) NOT NULL DEFAULT 0,
    max_wa_groups INT NOT NULL DEFAULT 1,
    monthly_token_quota BIGINT NOT NULL DEFAULT 500000,
    allowed_presets JSON NULL,
    features JSON NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);
```

### 9.2 `company_memberships`
```sql
CREATE TABLE company_memberships (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id BIGINT UNSIGNED NOT NULL,
    plan_id BIGINT UNSIGNED NOT NULL,
    status ENUM('trial','active','past_due','cancelled') NOT NULL DEFAULT 'trial',
    starts_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP NULL,
    max_wa_groups INT NOT NULL DEFAULT 1,
    monthly_token_quota BIGINT NOT NULL DEFAULT 500000,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_memberships_company (company_id),
    CONSTRAINT fk_memberships_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    CONSTRAINT fk_memberships_plan FOREIGN KEY (plan_id) REFERENCES membership_plans(id)
);
```

---

## 10. Uji Kebenaran Data
Setiap tabel baru WAJIB punya `company_id` (FK ke `companies`) untuk scoping tenant. Test isolasi tenant A vs B wajib ditulis untuk setiap modul.
