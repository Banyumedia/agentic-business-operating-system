# PRD: Agentic Business Operating System (BOS)
## ERP Nalarin Multi-Business Multi-Tenant Platform

**Versi:** 1.0.0-PROD  
**Status:** APPROVED FOR AUTONOMOUS EXECUTION  
**Target Codebase:** `/home/tejo/agentic/projects/erp-prime` (Laravel 13 / PHP 8.3 / MySQL / Tailwind v3 / Alpine.js)  
**Tujuan Dokumen:** Acuan mutlak bagi Autonomous AI Agents untuk membangun fitur tanpa perlu klarifikasi manual berulang.

---

## 1. Executive Summary & Visi Produk

**Agentic Business Operating System (BOS)** bukan sekadar ERP tradisional. Ini adalah *operating system* bisnis yang menyatukan:
1. **Zero-Bloat Dynamic UI:** Antarmuka web minimalis yang hanya memunculkan menu, field, dan kartu aksi yang benar-benar relevan dengan model bisnis tenant.
2. **Multi-Business Multi-Tenant Kernel:** Mendukung berbagai model industri (Agency, F&B, Apotek, Event Organizer, Kontraktor, Persewaan) di atas satu kernel arsitektur yang sama tanpa percabangan hardcode.
3. **Conversational Agentic Layer (WhatsApp/Telegram):** Transaksi harian (80%) dapat dipantau dan dieksekusi via chat dengan protokol keamanan *prepare → preview → confirm*.
4. **Indonesian Tax & Regulatory Compliance:** Fleksibilitas penuh pembukuan pajak (taxable PKP vs non-taxable, tax-inclusive vs tax-exclusive, perhitungan otomatis DPP/PPN 11%, FEFO apotek Kemenkes).

---

## 2. Empat Pilar Arsitektur Inti

### Pilar 1: Data-Driven Preset & Fitur Dinamis (Bukan Hardcode)
- Setiap `Company` terikat pada satu `business_preset` (`agency`, `fnb`, `pharmacy`, `eo`, `contractor`, `rental`, `custom`).
- Setiap modul/fitur dikontrol via allowlist key berhierarki (`crm.leads`, `crm.pic`, `pos.open_bill`, `pharmacy.fefo`, `contractor.retention`).
- Tenant dapat meng-override konfigurasi preset default melalui menu pengaturan tanpa mengubah kode aplikasi.

### Pilar 2: Dynamic Navigation & Zero-Bloat Sidebar
- Sidebar kiri dirender melalui `DynamicMenuRegistry` terpusat.
- Item menu Level 1 (Modul) dan Level 2 (Sub-fitur) diuji terhadap `company->feature($key)`.
- Jika fitur mati, menu **hilang total dari DOM** (bukan disabled / greyed out).

### Pilar 3: Dual-Mode Tax & Financial Book
- Pemisahan dimensi: `Company` (Workspace) → `BusinessIdentity` (Brand/Kop/NPWP) → `FinancialBook` (Buku Pajak).
- Setiap `BusinessIdentity` memiliki konfigurasi:
  - `tax_mode`: `taxable` (PKP) atau `non_taxable` (Non-PKP).
  - `price_includes_tax`: `true` (Harga retail sudah termasuk PPN) atau `false` (PPN ditambahkan di akhir).
  - Perhitungan DPP: Saat `price_includes_tax = true`, maka `DPP = Total / (1 + TaxRate)` dan `PPN = Total - DPP`.

### Pilar 4: Integrasi Asinkron NalarinPesan (F&B / Resto Bridge)
- NalarinPesan (`/home/tejo/agentic/projects/nalar-pesan`) tetap sebagai aplikasi terpisah (front-facing QR meja, menu tamu, checkout Pakasir QRIS).
- Integrasi ke ERP Prime dilakukan via **Webhook Asinkron → Agent Gateway**:
  - Event `order.created` / `payment.confirmed` dari NalarinPesan masuk ke endpoint webhook ERP.
  - ERP memvalidasi idempotency key, mencatat customer di CRM, memotong stok bahan (BOM), dan mencatat transaksi POS/Open Bill.
  - Tidak ada penggabungan database langsung antara NalarinPesan dan ERP Prime.

---

## 3. Batasan Produk (Non-Goals / Boundaries)

Untuk menjaga eksekusi agent tetap fokus dan selesai, fitur berikut **DILARANG / OUT OF SCOPE** untuk fase ini:
1. **Dilarang Payroll / HR Kompleks:** Penggajian karyawan, absensi GPS, dan PPh 21 ditahan.
2. **Dilarang Direct Core Upstream Fork:** Jangan memodifikasi vendor framework atau package eksternal.
3. **Dilarang Auto-Journal Liar:** Semua jurnal akuntansi harus memiliki pemicu dokumen operasional yang sah.
4. **Dilarang Multi-Tenancy Campur Database untuk Klien SaaS Baru:** Klien eksternal harus mengikuti arsitektur 1 database per tenant yang sudah dipersiapkan di `TenantProvisioner`.

---

## 4. Struktur Dokumen PRD Pendukung

Agent pelaksana wajib membaca dokumen pendukung di folder ini:
1. `INDUSTRY_PRESETS.md` — Matriks konfigurasi 6 industri & pemetaan menu.
2. `DATA_MODEL.md` — Perubahan skema migration & database contracts.
3. `REQUIREMENTS.md` — Spesifikasi fungsional mendalam per modul.
4. `EXECUTION_PLAN.md` — Daftar task terurut yang siap dieksekusi autopilot.
