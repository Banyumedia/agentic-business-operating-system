# REQUIREMENTS SPECIFICATION
## Spesifikasi Fungsional & Aturan Bisnis per Modul

---

## 1. Modul Pajak: PPN Inklusif, Eksklusif & Rekap DPP (Universal)

### 1.1 Kebutuhan Bisnis
- **Aturan Pajak Indonesia:** Banyak bisnis retail (Resto, Kafe, Apotek) mencantumkan harga jual yang sudah mencakup PPN 11% (*tax-inclusive*). Sebaliknya, transaksi B2B (Agency, Kontraktor, EO) umumnya menambahkan PPN di luar harga (*tax-exclusive*).
- Sistem wajib mendukung kedua metode ini secara dinamis per `BusinessIdentity` dan per dokumen transaksi.

### 1.2 Formula Perhitungan Matematis
Misalkan:
- `Subtotal` = Jumlah harga item
- `TaxRate` = 0.11 (11%)

#### Skenario A: `price_includes_tax = false` (Tax-Exclusive)
- `DPP` = `Subtotal`
- `PPN` = `round(DPP * TaxRate, 2)`
- `GrandTotal` = `DPP + PPN`

#### Skenario B: `price_includes_tax = true` (Tax-Inclusive)
- `GrandTotal` = `Subtotal` (Nilai yang dibayar pelanggan)
- `DPP` = `round(GrandTotal / (1 + TaxRate), 2)`
- `PPN` = `GrandTotal - DPP` (Menghindari selisih pembulatan)

### 1.3 Kontrak Implementasi di `TaxRateService.php`
```php
public function calculateTax(float $grossAmount, float $rate, bool $priceIncludesTax): TaxCalculationResult
{
    // Normalisasi $rate: cegah salah input pecahan vs persen (misal 11 atau 11.0 dikonversi ke 0.11)
    $normalizedRate = $rate > 1.0 ? $rate / 100.0 : $rate;

    if (! $priceIncludesTax) {
        $dpp = $grossAmount;
        $tax = round($dpp * $normalizedRate, 2);
        return new TaxCalculationResult(dpp: $dpp, tax: $tax, grandTotal: round($dpp + $tax, 2));
    }

    $dpp = round($grossAmount / (1.0 + $normalizedRate), 2);
    $tax = round($grossAmount - $dpp, 2);
    return new TaxCalculationResult(dpp: $dpp, tax: $tax, grandTotal: $grossAmount);
}
```

---

## 2. Dynamic Feature & Menu Registry (`DynamicMenuRegistry.php`)

### 2.1 Aturan Hard Runtime Gate
1. `Company` memiliki method helper:
   ```php
   public function feature(string $key): bool;
   public function hasAnyFeature(array $keys): bool;
   ```
2. Resolusi status fitur:
   - Cek apakah ada record override di `module_settings` untuk `company_id` aktif dengan key `features.{$key}`.
   - Jika ada, kembalikan nilai boolean dari override tersebut.
   - Jika tidak ada override, ambil default dari preset yang terpasang di `company->business_preset`.
3. **Sidebar Rendering:**
   - Navigasi sidebar di `resources/views/layouts/app.blade.php` harus membaca item dari `DynamicMenuRegistry::resolveFor(auth()->user(), current_company())`.
   - Item menu yang gagal evaluasi visibilitas **tidak boleh dirender ke HTML**.
4. **Route Protection:**
   - Middleware `EnsureFeatureEnabled:feature_key` harus memblokir akses direct URL dengan HTTP 403 Forbidden jika fitur terkait dimatikan untuk company tersebut.

---

## 3. Spesifikasi 6 Modul Industri Spesifik

### 3.1 Industri 1: Agency (Jasa Kreatif & IT)
- **CRM:** Menggunakan pipeline deals dengan tahapan: `Lead Baru → Pitch / SPH → Negosiasi → Won / Lost`. Field `pic_name`, `pic_wa`, dan `deal_value` wajib ada.
- **Operasional:** Timesheet per staf untuk menghitung biaya per jam pengerjaan proyek klien.
- **Invoicing:** Termin bertahap (contoh: DP 50%, Pelunasan 50% setelah serah terima).

### 3.2 Industri 2: F&B (Restoran, Kafe, FnB)
- **POS Meja (Open Bill):**
  - Kasir dapat membuka meja (contoh: Meja 04), mencatat pesanan awal, lalu mengirim pesanan ke dapur tanpa langsung meminta pembayaran.
  - Tambahan pesanan (re-fire) dapat digabungkan ke tagihan meja yang sama tanpa menduplikasi pesanan sebelumnya.
  - Checkout / Pembayaran dapat dilakukan tunai atau QRIS. Saat shift ditutup, sistem mencetak ringkasan kas masuk & selisih (*variance*).
- **Integrasi NalarinPesan:**
  - Tamu scan QR di meja → memesan via browser mobile → data masuk ke ERP via webhook.
  - Webhook controller memetakan pesanan tamu ke tagihan meja yang bersangkutan di ERP.

### 3.3 Industri 3: Apotek & Farmasi
- **Aturan FEFO (First Expired, First Out):**
  - Setiap batch obat memiliki `expired_date`. Sistem selalu menyarankan dan memotong stok dari batch dengan tanggal kedaluwarsa terdekat.
- **Validasi Resep Dokter:**
  - Obat golongan Keras / Psikotropika **dilarang dijual langsung** tanpa resep dokter.
  - Foto resep dokter diunggah ke sistem (atau via WA bot), diverifikasi oleh Apoteker yang bertugas (`pharmacist_verify`), baru kemudian dapat dilayani di kasir POS Apotek.

### 3.4 Industri 4: Event Organizer (EO)
- **Rundown & Timeline:**
  - Manajemen jadwal acara per menit/jam beserta penanggung jawab (PIC/Crew).
- **Vendor Matrix:**
  - Daftar vendor pihak ketiga (Sound System, Lighting, Panggung, Catering, Talent) yang terikat pada event tertentu beserta status pelunasan pembayarannya.

### 3.5 Industri 5: Kontraktor & Konstruksi
- **Surat Perintah Kerja (SPK) Subkon:**
  - Pencatatan pekerjaan yang dilempar ke mandor/subkontraktor.
- **Opname Progres Fisik (%):**
  - Penagihan ke pemberi kerja (Bouwheer) didasarkan pada Berita Acara Progres Fisik (contoh: Progres 35% tercapai).
- **Pemotongan Retensi:**
  - Otomatis memotong retensi pemeliharaan (biasanya 5%) dari setiap invoice progres, yang baru bisa ditagihkan 3-6 bulan setelah proyek serah terima final (FHO).

### 3.6 Industri 6: Persewaan (Rental Alat, Mobil, Venue)
- **Kalender Booking Unit:**
  - Tampilan visual status ketersediaan unit/armada pada tanggal tertentu untuk mencegah *double booking*.
- **Manajemen Deposit Jaminan & Denda:**
  - Pelanggan wajib menitipkan deposit uang/identitas saat pengambilan unit.
  - Jika pengembalian unit melebihi batas waktu (jam/hari), sistem otomatis menghitung denda keterlambatan saat check-in unit.
